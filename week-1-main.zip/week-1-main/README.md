a. What do you think are the differences between var, let, and const?
var gives you less control while let does and const makes the variable unavailable to change

b. How does this differ from other data structures that you are familiar with? Can 
you think of any advantages/disadvantages?
usually you have to define the data type before creating a variable but for js you dont which is an advantage in some ways 

c. How does this differ from other data structures that you are familiar with? Can 
you think of any advantages/disadvantages?
let reminds me of declaring data types in java and const reminds me of final in java

d. How do using classes differ from objects?
Classes can contain multiple objects and allow you to edit them while objects is just a group of properties that form something

e. What do you think are the differences between strict equality and abstract 
equality?
Strict eq is more commonly used and when you try to use abstact you culd get the same results but its less controlled and might throw errors 

f. Where do you think the concept of truthy/falsy might be useful?
Checking if a variable has any value to it, if not you can replace or put something in it
