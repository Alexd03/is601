#!/usr/bin/env node

const helloWorld =() => {
    return "hello, world!";
}
console.log(helloWorld());
